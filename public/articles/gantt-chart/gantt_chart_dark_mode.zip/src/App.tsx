/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';

const MONTHS = [
  "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
];

// Provide types for the tasks array
type Task = {
  id: string;
  isSpacer?: boolean;
  group?: string;
  label?: string;
  start?: string;
  end?: string;
  duration?: string;
};

const TASKS: Task[] = [
  { id: '1', group: 'Pre-Construction', label: "Site Prep & Clearing", start: "5/1/26", end: "16/1/26", duration: "2 wks" },
  { id: 'spacer1', isSpacer: true },
  { id: '2', group: 'Substructure', label: "Excavation & Formwork", start: "19/1/26", end: "30/1/26", duration: "2 wks" },
  { id: '3', group: 'Substructure', label: "Pour Foundation & Cure", start: "2/2/26", end: "13/2/26", duration: "2 wks" },
  { id: 'spacer2', isSpacer: true },
  { id: '4', group: 'Superstructure', label: "Wall Framing", start: "16/2/26", end: "13/3/26", duration: "4 wks" },
  { id: '5', group: 'Superstructure', label: "Roof Trusses", start: "16/3/26", end: "27/3/26", duration: "2 wks" },
  { id: 'spacer3', isSpacer: true },
  { id: '6', group: 'Enclosure', label: "Roofing & Sheeting", start: "30/3/26", end: "10/4/26", duration: "2 wks" },
  { id: '7', group: 'Enclosure', label: "Windows & Doors", start: "13/4/26", end: "24/4/26", duration: "2 wks" },
  { id: 'spacer4', isSpacer: true },
  { id: '8', group: 'Rough-Ins', label: "Plumbing", start: "27/4/26", end: "15/5/26", duration: "3 wks" },
  { id: '9', group: 'Rough-Ins', label: "HVAC", start: "11/5/26", end: "29/5/26", duration: "3 wks" },
  { id: '10', group: 'Rough-Ins', label: "Electrical", start: "25/5/26", end: "12/6/26", duration: "3 wks" },
  { id: 'spacer5', isSpacer: true },
  { id: '11', group: 'Interiors', label: "Insulation & Drywall", start: "15/6/26", end: "17/7/26", duration: "5 wks" },
  { id: '12', group: 'Interiors', label: "Painting", start: "20/7/26", end: "7/8/26", duration: "3 wks" },
  { id: '13', group: 'Interiors', label: "Cabinetry & Millwork", start: "10/8/26", end: "28/8/26", duration: "3 wks" },
  { id: '14', group: 'Interiors', label: "Flooring & Tiling", start: "31/8/26", end: "25/9/26", duration: "4 wks" },
  { id: 'spacer6', isSpacer: true },
  { id: '15', group: 'Exteriors', label: "Exterior Cladding", start: "1/6/26", end: "31/7/26", duration: "8 wks" },
  { id: '16', group: 'Exteriors', label: "Landscaping", start: "28/9/26", end: "23/10/26", duration: "4 wks" },
  { id: 'spacer7', isSpacer: true },
  { id: '17', group: 'Finishes', label: "Fixtures & Appliances", start: "28/9/26", end: "16/10/26", duration: "3 wks" },
  { id: '18', group: 'Finishes', label: "Final Clean & Defecting", start: "19/10/26", end: "6/11/26", duration: "3 wks" },
  { id: '19', group: 'Finishes', label: "Handover", start: "9/11/26", end: "20/11/26", duration: "2 wks" }
];

const getOffsets = (start: string, end: string) => {
  const parse = (d: string) => {
    let [day, month, year] = d.split('/').map(Number);
    if (year < 100) year += 2000;
    return { day, month, year };
  };
  const s = parse(start);
  const e = parse(end);
  
  const baseYear = 2026;
  const baseMonth = 1;
  
  const sMonthDiff = (s.year - baseYear) * 12 + (s.month - baseMonth);
  const eMonthDiff = (e.year - baseYear) * 12 + (e.month - baseMonth);
  
  const daysInMonth = (m: number, y: number) => new Date(y, m, 0).getDate();
  
  const sOffset = sMonthDiff + (s.day - 1) / daysInMonth(s.month, s.year);
  const eOffset = eMonthDiff + (e.day - 1) / daysInMonth(e.month, e.year);
  
  return { left: sOffset, width: eOffset - sOffset };
};

export default function App() {
  const getPct = (val: number) => `${Math.max(0, Math.min(1, val / 12)) * 100}%`;

  return (
    <div className="min-h-screen bg-white text-[#111111] font-sans pt-10 px-6 md:px-12 selection:bg-zinc-200">
      <div className="max-w-[1600px] mx-auto">
        
        <header className="pb-6 border-b border-[#eaeaea] mb-8">
          <span className="text-sm text-[#666666] font-medium block mb-2">Project Schedule</span>
          <h1 className="text-3xl font-medium m-0 tracking-tight text-[#111111]">Typical Single Storey Residential</h1>
        </header>

        <div className="flex bg-white rounded-xl border border-[#eaeaea] shadow-[0_2px_10px_rgba(0,0,0,0.02)] overflow-hidden mb-20">
          
          {/* Category pane */}
          <div className="w-[36px] md:w-[44px] shrink-0 border-r border-[#eaeaea] bg-[#fafafa] flex flex-col z-20 shadow-[1px_0_4px_rgba(0,0,0,0.02)] relative">
            <div className="h-[48px] border-b border-[#eaeaea]"></div>
            <div className="h-4"></div>
            {(() => {
              const elements = [];
              let currentGroup: string | null = null;
              let currentCount = 0;
              let keyCounter = 0;

              const flushGroup = () => {
                if (currentGroup && currentCount > 0) {
                  elements.push(
                    <div key={`group-${keyCounter++}`} className="flex items-center justify-center" style={{ height: currentCount * 48 }}>
                      <span className="text-[10px] font-bold text-[#888] uppercase tracking-widest whitespace-nowrap" style={{ writingMode: 'vertical-rl', transform: 'rotate(180deg)' }}>{currentGroup}</span>
                    </div>
                  );
                }
              };

              TASKS.forEach(task => {
                if (task.isSpacer) {
                  flushGroup();
                  elements.push(<div key={`spacer-${keyCounter++}`} className="h-[48px]"></div>);
                  currentGroup = null;
                  currentCount = 0;
                } else {
                  if (!currentGroup) currentGroup = task.group || null;
                  currentCount++;
                }
              });
              flushGroup();
              return elements;
            })()}
            <div className="h-4"></div>
          </div>

          {/* Left static pane */}
          <div className="w-[190px] md:w-[210px] shrink-0 border-r border-[#eaeaea] flex flex-col z-20 shadow-[1px_0_4px_rgba(0,0,0,0.02)] relative bg-white">
            <div className="h-[48px] grid grid-cols-3 border-b border-[#eaeaea] items-end pb-3 px-4 bg-[#fafafa] gap-2">
              <div className="text-[10px] font-bold text-[#888] uppercase tracking-widest leading-none text-left">Start</div>
              <div className="text-[10px] font-bold text-[#888] uppercase tracking-widest leading-none text-left">End</div>
              <div className="text-[10px] font-bold text-[#888] uppercase tracking-widest leading-none text-right">Dur</div>
            </div>
            
            <div className="h-4 bg-[#fafafa]"></div>
            
            <div className="flex flex-col bg-[#fafafa]">
              {TASKS.map((task) => {
                if (task.isSpacer) return <div key={task.id} className="h-[48px]"></div>;
                return (
                  <div key={task.id} className="h-[48px] grid grid-cols-3 items-center px-4 text-[10px] md:text-[11px] font-medium text-[#555] border-b border-transparent gap-2">
                    <div className="tracking-tight whitespace-nowrap text-left">{task.start}</div>
                    <div className="tracking-tight whitespace-nowrap text-left">{task.end}</div>
                    <div className="tracking-tight whitespace-nowrap text-right">{task.duration}</div>
                  </div>
                )
              })}
            </div>
            
            <div className="h-4 bg-[#fafafa]"></div>
          </div>

          {/* Right Gantt pane */}
          <div className="flex-1 overflow-hidden relative bg-white">
            <div className="w-full h-full relative px-4">
              
              <div className="h-[48px] border-b border-[#eaeaea] relative flex flex-col justify-end">
                {/* YEAR LABELS */}
                <div className="relative h-[20px] w-full">
                  <div className="absolute text-[#111] text-[11px] font-bold bottom-1" style={{ left: 0 }}>2026</div>
                </div>

                {/* MONTH LABELS */}
                <div className="relative h-[20px] w-full">
                  {MONTHS.map((month, i) => (
                    <div 
                      key={`month-${i}`}
                      className="absolute text-[#888] text-[9px] md:text-[10px] font-medium bottom-1 select-none"
                      style={{ left: getPct(i + 0.5), transform: 'translateX(-50%)' }}
                    >
                      {month}
                    </div>
                  ))}
                </div>
              </div>
              
              <div className="h-4"></div>
              
              {/* Timeline Grid */}
              <div 
                className="relative z-10 w-full"
                style={{ height: TASKS.length * 48 }}
              >
                {/* Background Grid Lines */}
                {[...Array(12)].map((_, i) => (
                  <div 
                    key={`bg-${i}`} 
                    className={`absolute top-0 bottom-0 border-l border-dashed border-[#e5e5e5] pointer-events-none ${i === 11 ? 'border-r' : ''}`}
                    style={{ left: getPct(i), width: getPct(1), zIndex: 0 }}
                  ></div>
                ))}

                {/* Tasks */}
                {TASKS.map((task, i) => {
                  if (task.isSpacer) return <div key={task.id}></div>;
                  const { left, width } = getOffsets(task.start!, task.end!);
                  return (
                    <div 
                      key={task.id}
                      className="absolute flex flex-col justify-end pb-[14px] group cursor-default"
                      style={{ 
                        top: i * 48, 
                        height: 48,
                        left: getPct(left), 
                        width: getPct(width) 
                      }}
                    >
                      <span className="absolute bottom-[24px] left-[2px] whitespace-nowrap z-20 text-[10px] md:text-[11px] text-[#111] drop-shadow-sm pointer-events-none">
                        {task.group ? <><span className="font-semibold">{task.group}</span>: </> : null}
                        <span className="text-[#555] font-normal">{task.label}</span>
                      </span>
                      <div className="h-[8px] bg-[#1c1c1c] rounded-full w-full relative z-10 group-hover:bg-[#444] transition-colors shadow-[0_1px_3px_rgba(0,0,0,0.1)]"></div>
                    </div>
                  );
                })}

              </div>
              
              <div className="h-4"></div>

            </div>
          </div>
          
        </div>
        
      </div>
    </div>
  );
}
