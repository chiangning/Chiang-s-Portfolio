/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Building2, 
  Calendar, 
  Clock, 
  CheckCircle2, 
  ChevronRight, 
  Share2, 
  Download, 
  MoreHorizontal, 
  Search, 
  Bell, 
  MessageSquare, 
  Briefcase, 
  Users, 
  Compass,
  ArrowRight,
  Sparkles,
  Layers,
  ThumbsUp,
  Heart,
  MessageCircle,
  Repeat2,
  Send,
  Check,
  Plus
} from 'lucide-react';

const MONTHS = [
  "Jan", "Feb", "Mar", "Apr", "May", "Jun", 
  "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
];

interface Task {
  id: string;
  phrase: string;
  group: 'Site & Found' | 'Lock-up Stage' | 'Fixing Stage' | 'Finishes';
  label: string;
  start: string;
  end: string;
  duration: string;
  progress: number;
}

const INITIAL_TASKS: Task[] = [
  { id: '1', phrase: 'site', group: 'Site & Found', label: "Site Prep & Footings", start: "01/01/26", end: "15/02/26", duration: "1.5m", progress: 100 },
  { id: '2', phrase: 'site', group: 'Site & Found', label: "Underground MEP & Slab", start: "16/02/26", end: "28/02/26", duration: "0.5m", progress: 100 },
  { id: '3', phrase: 'lock-up', group: 'Lock-up Stage', label: "Structural Framing", start: "01/03/26", end: "15/04/26", duration: "1.5m", progress: 85 },
  { id: '4', phrase: 'lock-up', group: 'Lock-up Stage', label: "Roof Installation", start: "16/04/26", end: "15/05/26", duration: "1.0m", progress: 40 },
  { id: '5', phrase: 'lock-up', group: 'Lock-up Stage', label: "Windows & Cladding", start: "16/05/26", end: "15/06/26", duration: "1.0m", progress: 0 },
  { id: '6', phrase: 'fixing', group: 'Fixing Stage', label: "MEP Rough-in", start: "16/06/26", end: "15/07/26", duration: "1.0m", progress: 0 },
  { id: '7', phrase: 'fixing', group: 'Fixing Stage', label: "Insulation & Drywall", start: "16/07/26", end: "15/08/26", duration: "1.0m", progress: 0 },
  { id: '8', phrase: 'fixing', group: 'Fixing Stage', label: "Cabinetry & Joinery", start: "16/08/26", end: "15/09/26", duration: "1.0m", progress: 0 },
  { id: '9', phrase: 'finishes', group: 'Finishes', label: "Painting & Tiling", start: "16/09/26", end: "15/10/26", duration: "1.0m", progress: 0 },
  { id: '10', phrase: 'finishes', group: 'Finishes', label: "Fixtures & Fit-off", start: "16/10/26", end: "15/11/26", duration: "1.0m", progress: 0 },
  { id: '11', phrase: 'finishes', group: 'Finishes', label: "Landscaping & Ext", start: "16/11/26", end: "10/12/26", duration: "0.8m", progress: 0 },
  { id: '12', phrase: 'finishes', group: 'Finishes', label: "Defects & Handover", start: "11/12/26", end: "31/12/26", duration: "0.7m", progress: 0 }
];

const getOffsets = (start: string, end: string) => {
  const parse = (d: string) => {
    let [day, month, year] = d.split('/').map(Number);
    if (year < 100) year += 2000;
    return { day, month, year };
  };
  const s = parse(start);
  const e = parse(end);
  
  const baseYear = 2026;
  const baseMonth = 1;
  
  const sMonthDiff = (s.year - baseYear) * 12 + (s.month - baseMonth);
  const eMonthDiff = (e.year - baseYear) * 12 + (e.month - baseMonth);
  
  const daysInMonth = (m: number, y: number) => new Date(y, m, 0).getDate();
  
  const sOffset = sMonthDiff + (s.day - 1) / daysInMonth(s.month, s.year);
  const eOffset = eMonthDiff + (e.day - 1) / daysInMonth(e.month, e.year);
  
  return { left: sOffset, width: eOffset - sOffset };
};

export default function App() {
  const [tasks, setTasks] = useState<Task[]>(INITIAL_TASKS);
  const [selectedTab, setSelectedTab] = useState<'all' | 'site' | 'lock-up' | 'fixing' | 'finishes'>('all');
  const [hoveredTask, setHoveredTask] = useState<string | null>(null);
  const [editingTask, setEditingTask] = useState<Task | null>(null);
  
  // LinkedIn social interaction states
  const [likeCount, setLikeCount] = useState(142);
  const [hasLiked, setHasLiked] = useState(false);
  const [commentInput, setCommentInput] = useState('');
  const [comments, setComments] = useState<{name: string, title: string, text: string, time: string}[]>([
    { name: "Sarah Jenkins", title: "Lead Architect • AI Studio Partners", text: "Brilliant sequence! The lock-up overlap with roofing and windows minimizes weather risks perfectly.", time: "2h ago" },
    { name: "David Chen", title: "Principal Site Supervisor", text: "Site prepping is scheduled nicely for optimal weather. Will track the MEP rough-in starts on phase 3 closely.", time: "5h ago" }
  ]);
  
  const getPct = (val: number) => `${(val / 12) * 100}%`;

  const filteredTasks = selectedTab === 'all' 
    ? tasks 
    : tasks.filter(t => t.phrase === selectedTab);

  const totalProgress = Math.round(
    tasks.reduce((sum, t) => sum + t.progress, 0) / tasks.length
  );

  const handleLike = () => {
    if (hasLiked) {
      setLikeCount(prev => prev - 1);
      setHasLiked(false);
    } else {
      setLikeCount(prev => prev + 1);
      setHasLiked(true);
    }
  };

  const handleAddComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!commentInput.trim()) return;
    setComments(prev => [
      {
        name: "You (Project Director)",
        title: "Construction Manager & Lead Estimator",
        text: commentInput,
        time: "Just now"
      },
      ...prev
    ]);
    setCommentInput('');
  };

  const updateProgress = (id: string, newProgress: number) => {
    setTasks(prev => prev.map(t => t.id === id ? { ...t, progress: Math.max(0, Math.min(100, newProgress)) } : t));
    if (editingTask && editingTask.id === id) {
      setEditingTask(prev => prev ? { ...prev, progress: newProgress } : null);
    }
  };

  const getGroupColor = (group: string) => {
    switch (group) {
      case 'Site & Found': return 'bg-[#007f5f]';
      case 'Lock-up Stage': return 'bg-[#0a66c2]';
      case 'Fixing Stage': return 'bg-[#ca6702]';
      default: return 'bg-[#6f2db8]';
    }
  };

  const getGroupTextClass = (group: string) => {
    switch (group) {
      case 'Site & Found': return 'text-[#007f5f] bg-[#007f5f]/10';
      case 'Lock-up Stage': return 'text-[#0a66c2] bg-[#0a66c2]/10';
      case 'Fixing Stage': return 'text-[#ca6702] bg-[#ca6702]/10';
      default: return 'text-[#6f2db8] bg-[#6f2db8]/10';
    }
  };

  return (
    <div className="min-h-[100dvh] bg-[#f4f2ee] flex flex-col font-sans text-zinc-900 selection:bg-[#0a66c2]/20">
      
      {/* LinkedIn-Style Top Navbar */}
      <nav className="h-[52px] bg-white border-b border-[#e8e9eb] fixed top-0 left-0 right-0 z-50 flex items-center justify-between px-4 md:px-8 shadow-sm">
        <div className="flex items-center gap-2 max-w-xl w-full">
          {/* LinkedIn Styled Logo */}
          <div className="flex items-center justify-center bg-[#0a66c2] text-white font-bold text-lg rounded px-2 py-0.5 tracking-tighter">
            in
          </div>
          <div className="text-sm font-semibold text-zinc-800 tracking-tight hidden sm:inline-block border-l border-zinc-200 pl-2 ml-1">
            BuildSchedule
          </div>
          <div className="relative flex-1 ml-2 max-w-xs">
            <span className="absolute inset-y-0 left-0 flex items-center pl-3">
              <Search className="h-4 w-4 text-zinc-400" />
            </span>
            <input 
              type="text" 
              placeholder="Search masterplans..." 
              className="w-full text-xs bg-[#eef3f8] pl-9 pr-3 py-1.5 rounded-md text-zinc-700 placeholder-zinc-500 focus:outline-none focus:ring-1 focus:ring-[#0a66c2] focus:bg-white transition-all"
            />
          </div>
        </div>

        {/* Global Nav Menu Items */}
        <div className="flex items-center gap-5 md:gap-7 text-zinc-500">
          <div className="flex flex-col items-center justify-center cursor-pointer text-zinc-900 hover:text-zinc-900 relative">
            <Briefcase className="h-5 w-5" />
            <span className="text-[10px] hidden md:inline mt-0.5">Projects</span>
            <div className="absolute -bottom-[15px] left-0 right-0 h-0.5 bg-[#0a66c2]"></div>
          </div>
          <div className="flex flex-col items-center justify-center cursor-pointer hover:text-zinc-900">
            <Users className="h-5 w-5" />
            <span className="text-[10px] hidden md:inline mt-0.5">Subcontractors</span>
          </div>
          <div className="flex flex-col items-center justify-center cursor-pointer hover:text-zinc-900 relative">
            <Bell className="h-5 w-5" />
            <span className="text-[10px] hidden md:inline mt-0.5">Alerts</span>
            <span className="absolute top-0 right-0.5 w-1.5 h-1.5 bg-[#007f5f] rounded-full"></span>
          </div>
          <div className="flex items-center gap-1 border-l border-zinc-200 pl-4">
            <div className="w-7 h-7 rounded-full bg-[#0a66c2] text-white text-xs font-bold flex items-center justify-center shadow-inner">
              PM
            </div>
            <div className="hidden lg:flex flex-col text-left ml-1">
              <span className="text-[10px] font-bold text-zinc-900 leading-tight">Project Director</span>
              <span className="text-[9px] text-[#666666] leading-none">CCK Devs</span>
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content Area */}
      <main className="flex-1 max-w-[1280px] w-full mx-auto px-2 md:px-6 pt-[72px] pb-6 flex flex-col justify-center items-center">
        
        {/* Linked-In Grid: Main dashboard feed item */}
        <div 
          className="w-full bg-white border border-[#e8e9eb] rounded-lg shadow-sm overflow-hidden flex flex-col justify-between"
          style={{ aspectRatio: '4/3', minHeight: '520px', maxHeight: '88vh' }}
        >
          
          {/* Post Heading Row */}
          <div className="p-4 border-b border-[#e8e9eb] flex items-center justify-between bg-white shrink-0">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-zinc-100 flex items-center justify-center border border-zinc-200 overflow-hidden shadow-sm">
                <Building2 className="w-5 h-5 text-[#0a66c2]" />
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <h2 className="text-sm font-semibold text-zinc-900 hover:text-[#0a66c2] cursor-pointer">
                    CCK Premium Constructions
                  </h2>
                  <span className="text-[10px] bg-[#0a66c2]/10 text-[#0a66c2] px-1.5 py-0.2 rounded font-medium">Verified Org</span>
                </div>
                <div className="text-[11px] text-[#666666] flex items-center gap-1.5 mt-0.5">
                  <span>12-Month Single-Storey Build Plan</span>
                  <span>•</span>
                  <span className="flex items-center gap-0.5">
                    <Clock className="w-3 h-3" /> Target: Dec 2026
                  </span>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-xs bg-[#007f5f]/10 text-[#007f5f] px-2.5 py-1 rounded-full font-semibold flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-[#007f5f] animate-pulse"></span>
                On Schedule
              </span>
              <button 
                onClick={() => {
                  const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(tasks, null, 2));
                  const downloadAnchor = document.createElement('a');
                  downloadAnchor.setAttribute("href", dataStr);
                  downloadAnchor.setAttribute("download", "CCK_Single_Storey_Masterplan.json");
                  document.body.appendChild(downloadAnchor);
                  downloadAnchor.click();
                  downloadAnchor.remove();
                }}
                className="p-1.5 text-zinc-500 hover:text-zinc-800 rounded-md hover:bg-zinc-100 transition-colors"
                title="Export Masterplan"
              >
                <Download className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Core Interactive Statistics Bar */}
          <div className="bg-[#fafbfe] px-4 md:px-6 py-3 border-b border-[#e8e9eb] grid grid-cols-4 divide-x divide-zinc-200 shrink-0 text-center">
            <div>
              <span className="block text-[10px] text-zinc-500 font-semibold uppercase tracking-wider">Project Scope</span>
              <span className="text-xs md:text-sm font-bold text-zinc-900 mt-0.5 block">12 Months (2026)</span>
            </div>
            <div>
              <span className="block text-[10px] text-zinc-500 font-semibold uppercase tracking-wider">Overall Progress</span>
              <span className="text-xs md:text-sm font-bold text-[#0a66c2] mt-0.5 block flex items-center justify-center gap-1">
                {totalProgress}%
                <span className="text-[9px] font-normal text-zinc-400">({tasks.filter(t => t.progress === 100).length}/12 Done)</span>
              </span>
            </div>
            <div>
              <span className="block text-[10px] text-zinc-500 font-semibold uppercase tracking-wider">Current Phase</span>
              <span className="text-xs md:text-sm font-bold text-zinc-900 mt-0.5 block truncate">
                {totalProgress < 20 ? 'Foundations' : totalProgress < 50 ? 'Lock-up Shell' : totalProgress < 75 ? 'Interior Fixing' : 'Final Finishes'}
              </span>
            </div>
            <div>
              <span className="block text-[10px] text-zinc-500 font-semibold uppercase tracking-wider">Interactive Mode</span>
              <span className="text-[10px] md:text-xs text-zinc-500 mt-1 block flex items-center justify-center gap-1 font-medium">
                <Sparkles className="w-3 h-3 text-amber-500" /> Hover & Track Active
              </span>
            </div>
          </div>

          {/* Interactive Phase Filters */}
          <div className="px-4 py-2 border-b border-[#e8e9eb] bg-white flex items-center gap-1.5 overflow-x-auto shrink-0 scrollbar-none">
            <span className="text-xs font-semibold text-zinc-500 mr-2 flex items-center gap-1">
              <Layers className="w-3.5 h-3.5 text-zinc-400" /> Filters:
            </span>
            <button 
              onClick={() => setSelectedTab('all')}
              className={`text-xs px-3 py-1 rounded-full font-medium transition-colors whitespace-nowrap ${selectedTab === 'all' ? 'bg-[#0a66c2] text-white' : 'bg-zinc-100 text-zinc-600 hover:bg-zinc-200'}`}
            >
              All Phases
            </button>
            <button 
              onClick={() => setSelectedTab('site')}
              className={`text-xs px-3 py-1 rounded-full font-medium transition-colors whitespace-nowrap ${selectedTab === 'site' ? 'bg-[#007f5f] text-white' : 'bg-emerald-50 text-emerald-800 hover:bg-emerald-100'}`}
            >
              Site & Found
            </button>
            <button 
              onClick={() => setSelectedTab('lock-up')}
              className={`text-xs px-3 py-1 rounded-full font-medium transition-colors whitespace-nowrap ${selectedTab === 'lock-up' ? 'bg-[#0a66c2] text-white' : 'bg-blue-50 text-blue-800 hover:bg-blue-100'}`}
            >
              Lock-up Stage
            </button>
            <button 
              onClick={() => setSelectedTab('fixing')}
              className={`text-xs px-3 py-1 rounded-full font-medium transition-colors whitespace-nowrap ${selectedTab === 'fixing' ? 'bg-[#ca6702] text-white' : 'bg-amber-50 text-amber-800 hover:bg-amber-100'}`}
            >
              Fixing Stage
            </button>
            <button 
              onClick={() => setSelectedTab('finishes')}
              className={`text-xs px-3 py-1 rounded-full font-medium transition-colors whitespace-nowrap ${selectedTab === 'finishes' ? 'bg-[#6f2db8] text-white' : 'bg-purple-50 text-purple-800 hover:bg-purple-100'}`}
            >
              Finishes & Handover
            </button>
          </div>

          {/* Interactive Gantt Chart Core Layout */}
          <div className="flex-1 flex overflow-hidden bg-white">
            
            {/* Table Details left sidebar */}
            <div className="w-[190px] md:w-[250px] shrink-0 border-r border-[#e8e9eb] flex flex-col z-20 bg-white">
              <div className="h-9 border-b border-[#e8e9eb] shrink-0 grid grid-cols-[1fr_auto] gap-2 items-center px-4 bg-[#fafbfe]">
                <div className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest text-left">Task Workstream</div>
                <div className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest text-right">Dur</div>
              </div>
              
              <div className="flex-1 flex flex-col py-1 overflow-hidden">
                {filteredTasks.map((task) => (
                  <div 
                    key={task.id}
                    onMouseEnter={() => setHoveredTask(task.id)}
                    onMouseLeave={() => setHoveredTask(null)}
                    onClick={() => setEditingTask(task)}
                    className={`flex-1 flex items-center justify-between px-3 md:px-4 cursor-pointer transition-all border-b border-zinc-100/40 select-none ${hoveredTask === task.id ? 'bg-[#eef3f8]/80 text-[#0a66c2]' : 'bg-white'}`}
                  >
                    <div className="min-w-0 pr-1 text-left">
                      <div className="flex items-center gap-1.5">
                        {task.progress === 100 ? (
                          <CheckCircle2 className="w-3.5 h-3.5 text-[#007f5f] shrink-0" />
                        ) : (
                          <div className={`w-1.5 h-1.5 rounded-full ${getGroupColor(task.group)} shrink-0`} />
                        )}
                        <span className={`text-[10px] md:text-[11px] truncate block ${hoveredTask === task.id ? 'font-semibold' : 'text-zinc-800 font-medium'}`}>
                          {task.label}
                        </span>
                      </div>
                      <div className="text-[8px] md:text-[9px] text-[#666666] flex items-center gap-1 whitespace-nowrap overflow-hidden mt-0.5">
                        <span className="font-semibold">{task.start}</span>
                        <span>to</span>
                        <span className="font-semibold">{task.end}</span>
                      </div>
                    </div>
                    <div className="text-[10px] font-bold text-zinc-600 bg-zinc-100 px-1.5 py-0.5 rounded shrink-0 whitespace-nowrap ml-1 text-right">
                      {task.duration}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Gantt chart right grid */}
            <div className="flex-1 flex flex-col relative bg-white overflow-hidden">
              
              {/* Year & Months header columns */}
              <div className="h-9 border-b border-[#e8e9eb] shrink-0 relative flex flex-col justify-end px-4 bg-[#fafbfe]">
                <div className="absolute top-[3px] left-4 text-[#0a66c2] text-[9px] lg:text-[10px] font-extrabold tracking-tight">
                  BUILD GRID: 12-PHASE TRACKER
                </div>
                
                <div className="relative h-[16px] w-full">
                  {MONTHS.map((month, i) => (
                    <div 
                      key={`month-${i}`}
                      className="absolute text-zinc-500 text-[9px] md:text-[10px] font-semibold bottom-0.5 select-none"
                      style={{ left: getPct(i + 0.5), transform: 'translateX(-50%)' }}
                    >
                      {month}
                    </div>
                  ))}
                </div>
              </div>
              
              {/* Timeline layout panel */}
              <div className="flex-1 relative mx-4 py-1 select-none">
                
                {/* Visual Month Vertical Separators */}
                {[...Array(13)].map((_, i) => (
                  <div 
                    key={`bg-${i}`} 
                    className="absolute top-0 bottom-0 border-l border-dashed border-zinc-200/70 pointer-events-none"
                    style={{ left: getPct(i), zIndex: 0 }}
                  ></div>
                ))}

                {/* Timeline Horizontal Rows */}
                <div className="absolute inset-x-0 inset-y-1 flex flex-col z-10">
                  {filteredTasks.map((task) => {
                    const { left, width } = getOffsets(task.start, task.end);
                    const isHovered = hoveredTask === task.id;
                    const isLeftAligned = left > 6;
                    
                    return (
                      <div 
                        key={task.id} 
                        onMouseEnter={() => setHoveredTask(task.id)}
                        onMouseLeave={() => setHoveredTask(null)}
                        onClick={() => setEditingTask(task)}
                        className="flex-1 relative group cursor-pointer"
                      >
                        {/* Dynamic background highlight row */}
                        <div className={`absolute inset-0 transition-opacity pointer-events-none -mx-4 ${isHovered ? 'bg-[#eef3f8]/50 opacity-100' : 'opacity-0'}`} />
                        
                        {/* Progressive Gantt Slider Row */}
                        <div 
                          className="absolute h-full flex flex-col justify-center"
                          style={{ 
                            left: getPct(left), 
                            width: getPct(width) 
                          }}
                        >
                          {/* Top floating absolute Label */}
                          <span className={`absolute bottom-[calc(50%+4px)] text-[9px] md:text-[10px] font-bold tracking-tight text-zinc-800 whitespace-nowrap uppercase transition-all duration-150 pointer-events-none ${isHovered ? 'scale-105 origin-left text-[#0a66c2]' : 'opacity-80'} ${isLeftAligned ? 'right-1 text-right' : 'left-0.5 text-left'}`}>
                            {task.label}
                          </span>

                          {/* Double layered visual progress bar */}
                          <div className="h-2 rounded-full bg-zinc-100 border border-zinc-200/50 w-full relative z-10 shadow-sm overflow-hidden flex">
                            
                            {/* Inner Completed bar */}
                            <div 
                              className={`h-full transition-all duration-300 ${getGroupColor(task.group)}`} 
                              style={{ width: `${task.progress}%` }} 
                            />
                            
                            {/* Inner Uncompleted buffer */}
                            <div className="flex-1 h-full bg-zinc-200 bg-opacity-30" />
                          </div>

                          {/* Dynamic detailed percent tag */}
                          <span className={`absolute top-[calc(50%+4px)] text-[8px] font-mono text-zinc-500 font-bold tracking-tighter ${isLeftAligned ? 'right-1 text-right' : 'left-0.5 text-left'}`}>
                            {task.progress}% done
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>

              </div>
            </div>
            
          </div>

          {/* Interactive Right Detail & Custom Adjustment Slider Panel (Side Overlayer) */}
          {editingTask && (
            <div className="fixed inset-0 bg-black/30 backdrop-blur-xs flex items-center justify-center z-50 p-4 animate-fade-in">
              <div className="bg-white rounded-lg border border-zinc-200 shadow-2xl p-5 w-full max-w-sm relative">
                <button 
                  onClick={() => setEditingTask(null)}
                  className="absolute top-3 right-3 text-zinc-400 hover:text-zinc-600 font-bold text-lg"
                >
                  ✕
                </button>
                <div className="flex items-center gap-2 mb-3">
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${getGroupTextClass(editingTask.group)}`}>
                    {editingTask.group}
                  </span>
                  <span className="text-[10px] text-[#666666] font-semibold">CCK Build Phase</span>
                </div>
                
                <h3 className="text-sm font-bold text-zinc-900 mb-4">{editingTask.label}</h3>
                
                <div className="space-y-4 mb-5">
                  <div className="grid grid-cols-2 gap-3 bg-[#fafbfe] p-3 rounded-md border border-zinc-100">
                    <div>
                      <span className="block text-[8px] font-bold uppercase text-zinc-400 tracking-wider">Start Date</span>
                      <span className="text-xs font-semibold text-zinc-800">{editingTask.start}</span>
                    </div>
                    <div>
                      <span className="block text-[8px] font-bold uppercase text-zinc-400 tracking-wider">End Date</span>
                      <span className="text-xs font-semibold text-zinc-800">{editingTask.end}</span>
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between items-center text-xs font-semibold mb-1">
                      <span className="text-zinc-600">Actual Work Progress</span>
                      <span className="text-[#0a66c2]">{editingTask.progress}% Complete</span>
                    </div>
                    <input 
                      type="range" 
                      min="0" 
                      max="100" 
                      value={editingTask.progress}
                      onChange={(e) => updateProgress(editingTask.id, parseInt(e.target.value))}
                      className="w-full h-1.5 bg-zinc-200 rounded-lg appearance-none cursor-pointer accent-[#0a66c2]"
                    />
                  </div>
                </div>

                <div className="flex gap-2">
                  <button 
                    onClick={() => {
                      updateProgress(editingTask.id, 100);
                      setEditingTask(null);
                    }}
                    className="flex-1 py-1.5 rounded bg-[#007f5f] hover:bg-[#005f47] text-white font-semibold text-xs transition-colors"
                  >
                    Mark 100% Done
                  </button>
                  <button 
                    onClick={() => setEditingTask(null)}
                    className="flex-1 py-1.5 rounded border border-[#0a66c2] hover:bg-blue-50 text-[#0a66c2] font-semibold text-xs transition-colors"
                  >
                    Save Changes
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* LinkedIn Footer - Interactive Reaction Bar (Operable) */}
          <div className="px-4 py-2 border-t border-[#e8e9eb] bg-[#fafbfe] shrink-0 flex items-center justify-between text-xs text-zinc-500 font-semibold select-none">
            <div className="flex items-center gap-1.5 text-zinc-500 text-[11px]">
              <div className="flex -space-x-1">
                <span className="w-4 h-4 rounded-full bg-[#0a66c2] text-white text-[8px] font-bold flex items-center justify-center border border-white">
                  👍
                </span>
                <span className="w-4 h-4 rounded-full bg-[#007f5f] text-white text-[8px] font-bold flex items-center justify-center border border-white">
                  ❤️
                </span>
              </div>
              <span className="hover:underline hover:text-[#0a66c2] cursor-pointer">
                You and {likeCount} others
              </span>
              <span>•</span>
              <span className="hover:underline hover:text-[#0a66c2] cursor-pointer">
                {comments.length} comments
              </span>
            </div>
            
            <div className="flex items-center gap-2">
              <span className="text-[10px] text-zinc-400 font-normal hidden sm:inline">
                Click cells or labels to adjust progress dials!
              </span>
            </div>
          </div>

          {/* Social Command Actions Panel */}
          <div className="px-2 md:px-4 py-1 bg-white border-t border-[#e8e9eb] flex items-center justify-around text-xs font-semibold text-zinc-600 shrink-0">
            <button 
              onClick={handleLike}
              className={`flex-1 flex items-center justify-center gap-1.5 py-1.5 hover:bg-zinc-100 rounded-md transition-colors ${hasLiked ? 'text-[#0a66c2]' : 'text-zinc-600'}`}
            >
              <ThumbsUp className="w-4 h-4" />
              <span>Like</span>
            </button>
            <button className="flex-1 flex items-center justify-center gap-1.5 py-1.5 text-zinc-600 hover:bg-zinc-100 rounded-md transition-colors">
              <MessageCircle className="w-4 h-4" />
              <span>Comment</span>
            </button>
            <button className="flex-1 flex items-center justify-center gap-1.5 py-1.5 text-zinc-600 hover:bg-zinc-100 rounded-md transition-colors">
              <Repeat2 className="w-4 h-4" />
              <span>Repost</span>
            </button>
            <button 
              onClick={() => {
                const dummyLink = window.location.href;
                navigator.clipboard.writeText(dummyLink);
                alert("Project Schedule Link copied to clipboard!");
              }}
              className="flex-1 flex items-center justify-center gap-1.5 py-1.5 text-zinc-600 hover:bg-zinc-100 rounded-md transition-colors"
            >
              <Send className="w-4 h-4" />
              <span>Send</span>
            </button>
          </div>

          {/* LinkedIn Interactive Real Comment Box & Feeds */}
          <div className="bg-[#fafbfe] p-3 border-t border-[#e8e9eb] shrink-0 max-h-[140px] overflow-y-auto custom-scrollbar flex flex-col gap-3">
            
            <form onSubmit={handleAddComment} className="flex gap-2">
              <div className="w-7 h-7 rounded-full bg-zinc-300 text-zinc-700 font-bold text-xs flex items-center justify-center shrink-0 border border-zinc-200">
                U
              </div>
              <div className="flex-1 flex gap-1 items-center">
                <input 
                  type="text" 
                  value={commentInput}
                  onChange={(e) => setCommentInput(e.target.value)}
                  placeholder="Post an update or estimate feedback on this timeline..." 
                  className="flex-1 bg-white border border-zinc-200 rounded-full px-4 py-1.5 text-xs placeholder-zinc-400 focus:outline-none focus:ring-1 focus:ring-[#0a66c2]"
                />
                <button 
                  type="submit" 
                  disabled={!commentInput.trim()}
                  className="bg-[#0a66c2] hover:bg-[#004182] disabled:opacity-50 text-white p-2 rounded-full transition-opacity cursor-pointer shrink-0"
                >
                  <Send className="w-3.5 h-3.5" />
                </button>
              </div>
            </form>

            <div className="space-y-3">
              {comments.map((comment, idx) => (
                <div key={idx} className="flex gap-2.5 text-left items-start bg-white p-2.5 rounded border border-[#eaeaea]">
                  <div className="w-6 h-6 rounded-full bg-slate-200 text-zinc-700 text-[10px] font-bold flex items-center justify-center shrink-0">
                    {comment.name.slice(0, 1)}
                  </div>
                  <div>
                    <div className="flex items-baseline gap-1.5">
                      <span className="text-xs font-bold text-zinc-800">{comment.name}</span>
                      <span className="text-[8px] text-zinc-400 font-medium">{comment.time}</span>
                    </div>
                    <p className="text-[9px] text-[#666666] leading-none mb-1">{comment.title}</p>
                    <p className="text-xs text-zinc-700 font-normal leading-relaxed">{comment.text}</p>
                  </div>
                </div>
              ))}
            </div>

          </div>

        </div>
        
      </main>
    </div>
  );
}
