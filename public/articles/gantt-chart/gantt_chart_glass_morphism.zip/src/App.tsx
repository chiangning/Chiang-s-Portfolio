/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useMemo } from 'react';

const MONTHS = [
  "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
];

// Provide types for the tasks array
type Task = {
  id: string;
  isSpacer?: boolean;
  group?: string;
  label?: string;
  start?: string;
  end?: string;
  duration?: string;
};

const TASKS: Task[] = [
  { id: '1', group: 'Pre-Construction', label: "Site Prep & Clearing", start: "5/1/26", end: "16/1/26", duration: "2 wks" },
  { id: 'spacer1', isSpacer: true },
  { id: '2', group: 'Substructure', label: "Excavation & Formwork", start: "19/1/26", end: "30/1/26", duration: "2 wks" },
  { id: '3', group: 'Substructure', label: "Pour Foundation & Cure", start: "2/2/26", end: "13/2/26", duration: "2 wks" },
  { id: 'spacer2', isSpacer: true },
  { id: '4', group: 'Superstructure', label: "Wall Framing", start: "16/2/26", end: "13/3/26", duration: "4 wks" },
  { id: '5', group: 'Superstructure', label: "Roof Trusses", start: "16/3/26", end: "27/3/26", duration: "2 wks" },
  { id: 'spacer3', isSpacer: true },
  { id: '6', group: 'Enclosure', label: "Roofing & Sheeting", start: "30/3/26", end: "10/4/26", duration: "2 wks" },
  { id: '7', group: 'Enclosure', label: "Windows & Doors", start: "13/4/26", end: "24/4/26", duration: "2 wks" },
  { id: '15', group: 'Enclosure', label: "Exterior Cladding", start: "27/4/26", end: "5/6/26", duration: "6 wks" },
  { id: 'spacer4', isSpacer: true },
  { id: '8', group: 'Rough-Ins', label: "Plumbing", start: "27/4/26", end: "15/5/26", duration: "3 wks" },
  { id: '9', group: 'Rough-Ins', label: "HVAC", start: "11/5/26", end: "29/5/26", duration: "3 wks" },
  { id: '10', group: 'Rough-Ins', label: "Electrical", start: "25/5/26", end: "12/6/26", duration: "3 wks" },
  { id: 'spacer5', isSpacer: true },
  { id: '11', group: 'Interiors', label: "Insulation & Drywall", start: "15/6/26", end: "17/7/26", duration: "5 wks" },
  { id: '12', group: 'Interiors', label: "Painting", start: "20/7/26", end: "7/8/26", duration: "3 wks" },
  { id: '13', group: 'Interiors', label: "Cabinetry & Millwork", start: "10/8/26", end: "28/8/26", duration: "3 wks" },
  { id: '14', group: 'Interiors', label: "Flooring & Tiling", start: "31/8/26", end: "25/9/26", duration: "4 wks" },
  { id: 'spacer6', isSpacer: true },
  { id: '16', group: 'Site Works', label: "Landscaping", start: "28/9/26", end: "23/10/26", duration: "4 wks" },
  { id: 'spacer7', isSpacer: true },
  { id: '17', group: 'Finishes', label: "Fixtures & Appliances", start: "26/10/26", end: "13/11/26", duration: "3 wks" },
  { id: '18', group: 'Finishes', label: "Final Clean & Defecting", start: "16/11/26", end: "27/11/26", duration: "2 wks" },
  { id: '19', group: 'Finishes', label: "Handover", start: "30/11/26", end: "11/12/26", duration: "2 wks" }
];

const getOffsets = (start: string, end: string) => {
  const parse = (d: string) => {
    let [day, month, year] = d.split('/').map(Number);
    if (year < 100) year += 2000;
    return { day, month, year };
  };
  const s = parse(start);
  const e = parse(end);
  
  const baseYear = 2026;
  const baseMonth = 1;
  
  const sMonthDiff = (s.year - baseYear) * 12 + (s.month - baseMonth);
  const eMonthDiff = (e.year - baseYear) * 12 + (e.month - baseMonth);
  
  const daysInMonth = (m: number, y: number) => new Date(y, m, 0).getDate();
  
  const sOffset = sMonthDiff + (s.day - 1) / daysInMonth(s.month, s.year);
  const eOffset = eMonthDiff + (e.day - 1) / daysInMonth(e.month, e.year);
  
  return { left: sOffset, width: eOffset - sOffset };
};

export default function App() {
  const getPct = (val: number) => `${Math.max(0, Math.min(1, val / 12)) * 100}%`;

  const ROW_HEIGHT = 36;
  const SPACER_HEIGHT = 16;
  const HEADER_HEIGHT = 44;

  const totalGridHeight = useMemo(() => TASKS.reduce((acc, task) => acc + (task.isSpacer ? SPACER_HEIGHT : ROW_HEIGHT), 0), []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-blue-50 to-sky-100 text-slate-800 font-sans pt-12 px-6 md:px-12 selection:bg-blue-200 relative overflow-hidden">
      {/* Decorative background blobs */}
      <div className="fixed top-[-10%] left-[-10%] w-[40%] h-[40%] rounded-full bg-blue-300/30 blur-[100px] pointer-events-none" />
      <div className="fixed bottom-[-10%] right-[-10%] w-[40%] h-[40%] rounded-full bg-indigo-300/30 blur-[100px] pointer-events-none" />
      
      <div className="max-w-[1600px] mx-auto relative z-10">
        
        <header className="pb-6 border-b border-white/50 mb-8">
          <span className="text-xs text-blue-500/80 font-semibold tracking-widest uppercase block mb-2 drop-shadow-sm">Project Schedule</span>
          <h1 className="text-3xl font-medium m-0 tracking-tight text-slate-800">Single Storey Residential</h1>
        </header>

        <div className="flex bg-white/40 rounded-2xl border border-white/60 shadow-[0_8px_32px_rgba(31,56,100,0.08)] overflow-hidden mb-20 backdrop-blur-md">
          
          {/* Category pane */}
          <div className="w-[36px] md:w-[44px] shrink-0 border-r border-white/50 bg-white/30 flex flex-col z-20">
            <div style={{ height: HEADER_HEIGHT }} className="border-b border-white/50"></div>
            <div className="h-4"></div>
            {(() => {
              const elements = [];
              let currentGroup: string | null = null;
              let currentHeight = 0;
              let keyCounter = 0;

              const flushGroup = () => {
                if (currentGroup && currentHeight > 0) {
                  elements.push(
                    <div key={`group-${keyCounter++}`} className="flex items-center justify-center relative border-r border-white/20" style={{ height: currentHeight }}>
                      <span className="text-[10px] font-bold text-slate-500/80 uppercase tracking-widest whitespace-nowrap drop-shadow-[0_1px_1px_rgba(255,255,255,0.8)]" style={{ writingMode: 'vertical-rl', transform: 'rotate(180deg)' }}>{currentGroup}</span>
                    </div>
                  );
                }
              };

              TASKS.forEach(task => {
                if (task.isSpacer) {
                  flushGroup();
                  elements.push(<div key={`spacer-${keyCounter++}`} style={{ height: SPACER_HEIGHT }}></div>);
                  currentGroup = null;
                  currentHeight = 0;
                } else {
                  if (!currentGroup) currentGroup = task.group || null;
                  currentHeight += ROW_HEIGHT;
                }
              });
              flushGroup();
              return elements;
            })()}
            <div className="h-4"></div>
          </div>

          {/* Left static pane */}
          <div className="w-[190px] md:w-[220px] shrink-0 border-r border-white/50 flex flex-col z-20 bg-white/40 shadow-[4px_0_12px_rgba(31,56,100,0.03)] relative backdrop-blur-sm">
            <div style={{ height: HEADER_HEIGHT }} className="grid grid-cols-3 border-b border-white/50 items-end pb-3 px-4 gap-2">
              <div className="text-[10px] font-bold text-slate-500/90 uppercase tracking-widest leading-none text-left drop-shadow-[0_1px_1px_rgba(255,255,255,0.8)]">Start</div>
              <div className="text-[10px] font-bold text-slate-500/90 uppercase tracking-widest leading-none text-left drop-shadow-[0_1px_1px_rgba(255,255,255,0.8)]">End</div>
              <div className="text-[10px] font-bold text-slate-500/90 uppercase tracking-widest leading-none text-right drop-shadow-[0_1px_1px_rgba(255,255,255,0.8)]">Dur</div>
            </div>
            
            <div className="h-4"></div>
            
            <div className="flex flex-col">
              {TASKS.map((task) => {
                if (task.isSpacer) return <div key={task.id} style={{ height: SPACER_HEIGHT }}></div>;
                return (
                  <div key={task.id} className="grid grid-cols-3 items-center px-4 text-[10px] md:text-[11px] font-medium text-slate-700 gap-2 transition-colors hover:bg-white/60 rounded-md mx-1" style={{ height: ROW_HEIGHT }}>
                    <div className="tracking-tight whitespace-nowrap text-left">{task.start}</div>
                    <div className="tracking-tight whitespace-nowrap text-left">{task.end}</div>
                    <div className="tracking-tight whitespace-nowrap text-right text-slate-500">{task.duration}</div>
                  </div>
                )
              })}
            </div>
            
            <div className="h-4"></div>
          </div>

          {/* Right Gantt pane */}
          <div className="flex-1 overflow-hidden relative bg-white/10">
            <div className="w-full h-full relative px-5">
              
              <div style={{ height: HEADER_HEIGHT }} className="border-b border-white/50 relative flex flex-col justify-end">
                {/* YEAR LABELS */}
                <div className="relative h-[20px] w-full">
                  <div className="absolute text-slate-800 text-[11px] font-bold bottom-1" style={{ left: 0 }}>2026</div>
                </div>

                {/* MONTH LABELS */}
                <div className="relative h-[20px] w-full">
                  {MONTHS.map((month, i) => (
                    <div 
                      key={`month-${i}`}
                      className="absolute text-slate-500 text-[9px] md:text-[10px] font-semibold bottom-1 select-none"
                      style={{ left: getPct(i + 0.5), transform: 'translateX(-50%)' }}
                    >
                      {month}
                    </div>
                  ))}
                </div>
              </div>
              
              <div className="h-4"></div>
              
              {/* Timeline Grid */}
              <div 
                className="relative z-10 w-full flex flex-col"
                style={{ height: totalGridHeight }}
              >
                {/* Background Grid Lines */}
                <div className="absolute top-0 bottom-0 left-0 right-0 z-0">
                  {[...Array(13)].map((_, i) => (
                    <div 
                      key={`bg-${i}`} 
                      className={`absolute top-0 bottom-0 border-l border-dashed border-slate-300/50 pointer-events-none`}
                      style={{ left: getPct(i), width: getPct(1) }}
                    ></div>
                  ))}
                </div>

                {/* Tasks */}
                <div className="relative z-10 w-full flex flex-col text-[10px] md:text-[11px]">
                  {TASKS.map((task) => {
                    if (task.isSpacer) return <div key={task.id} style={{ height: SPACER_HEIGHT }}></div>;
                    const { left, width } = getOffsets(task.start!, task.end!);
                    return (
                      <div key={task.id} className="relative w-full group cursor-default" style={{ height: ROW_HEIGHT }}>
                        <div 
                          className="absolute flex flex-col justify-end pb-[10px]"
                          style={{ height: '100%', left: getPct(left), width: getPct(width) }}
                        >
                          <span className="absolute bottom-[20px] left-[0px] whitespace-nowrap z-20 pointer-events-none px-1">
                            {task.group ? <><span className="font-semibold text-slate-500/80 drop-shadow-[0_1px_1px_rgba(255,255,255,0.8)]">{task.group}: </span></> : null}
                            <span className="font-semibold text-slate-700 drop-shadow-[0_1px_1px_rgba(255,255,255,0.8)]">{task.label}</span>
                          </span>
                          <div className="h-[8px] bg-gradient-to-r from-blue-400 to-indigo-400 rounded-full w-full relative z-10 group-hover:from-blue-500 group-hover:to-indigo-500 transition-colors shadow-[0_2px_8px_rgba(99,102,241,0.25)] ring-1 ring-white/60 backdrop-blur-md"></div>
                        </div>
                      </div>
                    );
                  })}
                </div>

              </div>
              
              <div className="h-4"></div>

            </div>
          </div>
          
        </div>
        
      </div>
    </div>
  );
}
